import sys
import os
import pyodbc
import json

data=[]
table=[]

cnxn = pyodbc.connect(r'Driver={SQL Server};Server=TECHNOTRON;Database=HerdmanData;Trusted_Connection=yes;')
cursor = cnxn.cursor()

def dbTest():
    
    cursor.execute("SELECT [Speciescode],[BreedCode],[Name],[BreedType],[SyncID] FROM [HerdmanData].[Common].[Breed]")

    rows=cursor.fetchall();

    for row in rows:
        data.append(row[0])
        
    return data

    cnxn.close()
    

def query_db(query, one=False):
    cnxn = pyodbc.connect(r'Driver={SQL Server};Server=TECHNOTRON;Database=HerdmanData;Trusted_Connection=yes;')
    
    cursor = cnxn.cursor()

    cursor.execute(query)
    r = [dict((cur.description[i][0], value) \
               for i, value in enumerate(row)) for row in cur.fetchall()]
    cursor.connection.close()
    return (r[0] if r else None) if one else r



def main():
    result=query_db("SELECT TOP (10) [Speciescode],[BreedCode],[Name],[BreedType],[SyncID] FROM [HerdmanData].[Common].[Breed]")
    jsonOutput=json.dumps(result)
    return result

if __name__ == '__main__':
    main()