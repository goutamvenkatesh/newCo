from flask import Flask
from flask import render_template,jsonify
import json
import dbConnect
import json


app = Flask(__name__, static_url_path="/static", static_folder='G:/newCo/software/dashboard sample 1/newDashWithFlask/newDash/static')


@app.route("/")
def index():
	tables=dbConnect.dbTest()
	return render_template("index.html",values=tables)


@app.route("/data")
def data():

	return jsonify({'results': dbConnect.dbTest()})



if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5000,debug=True)